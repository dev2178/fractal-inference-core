# Theory

FIC uses competitive parallel hypothesis verification. Agents randomly select rules and facts, performing unification and writing derived facts back to the blackboard. The process is inspired by stochastic local search and blackboard systems.