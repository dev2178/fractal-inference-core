# API Reference

- `FractalInferenceCore` – main engine
- `Blackboard` – shared memory
- `InferenceAgent` – reasoning unit
See header comments for details.