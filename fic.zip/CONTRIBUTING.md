# Contributing

- Use `.clang-format` for code style
- Add tests for new features
- Ensure all tests pass before PR