#pragma once
#include "core_types.h"
#include "blackboard.h"
#include <random>
#include <vector>

namespace fic {

class InferenceAgent {
public:
    InferenceAgent(int id,
                   const std::vector<Rule>& rules,
                   const RuleIndex& ruleIndex,
                   Blackboard& blackboard);
    void run(int iterations);

private:
    bool tryInferOnce();
    bool matchRule(const Rule& rule, BindingMap& outBindings);

    int id_;
    const std::vector<Rule>& rules_;
    const RuleIndex& ruleIndex_;
    Blackboard& board_;
    std::mt19937 rng_;
    std::uniform_real_distribution<double> noiseDist_{-0.02, 0.02};
};

} // namespace fic