#pragma once
#include <string>
#include <vector>
#include <unordered_map>

namespace fic {

struct TriplePattern {
    std::string predicate;
    std::string subject;
    std::string object;

    static bool isVariable(const std::string& s) noexcept {
        return !s.empty() && s[0] == '?';
    }
};

struct Fact {
    std::string predicate;
    std::string subject;
    std::string object;
    double confidence = 0.0;

    TriplePattern toPattern() const { return {predicate, subject, object}; }
};

struct Rule {
    std::vector<TriplePattern> premises;
    TriplePattern conclusion;
    double strength = 0.9;
};

using BindingMap = std::unordered_map<std::string, std::string>;
using RuleIndex = std::unordered_map<std::string, std::vector<size_t>>;

} // namespace fic