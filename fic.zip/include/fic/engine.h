#pragma once
#include "core_types.h"
#include "blackboard.h"
#include <memory>
#include <vector>

namespace fic {

class FractalInferenceCore {
public:
    FractalInferenceCore(std::vector<Rule> rules,
                         std::vector<Fact> initialFacts,
                         int numAgents = 4,
                         int iterationsPerAgent = 100);

    FractalInferenceCore(const FractalInferenceCore&) = delete;
    FractalInferenceCore& operator=(const FractalInferenceCore&) = delete;

    std::vector<Fact> infer(double confidenceThreshold = 0.6);
    void addFact(const Fact& f);
    size_t factCount() const;

private:
    void buildRuleIndex();

    std::vector<Rule> rules_;
    std::vector<Fact> initialFacts_;
    int numAgents_;
    int iterPerAgent_;
    std::unique_ptr<Blackboard> blackboard_;
    RuleIndex ruleIndex_;
};

} // namespace fic