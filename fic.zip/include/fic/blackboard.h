#pragma once
#include "core_types.h"
#include <shared_mutex>
#include <vector>
#include <unordered_map>
#include <optional>
#include <random>

namespace fic {

class Blackboard {
public:
    Blackboard() = default;
    Blackboard(const Blackboard&) = delete;
    Blackboard& operator=(const Blackboard&) = delete;

    void insert(const Fact& f);
    std::vector<Fact> getAllFacts() const;
    std::vector<Fact> getFactsByPredicate(const std::string& predicate) const;

    bool exists(const TriplePattern& pattern, const BindingMap& bindings,
                double minConf = 0.0) const;

    std::optional<Fact> getRandomMatching(const TriplePattern& pattern,
                                          const BindingMap& bindings,
                                          std::mt19937& rng,
                                          double minConf = 0.0) const;

    std::optional<Fact> getRandomFact(std::mt19937& rng) const;
    double getConfidence(const Fact& f) const;
    size_t size() const;

private:
    mutable std::shared_mutex mutex_;
    std::unordered_map<std::string, Fact> store_;
    std::unordered_map<std::string, std::vector<std::string>> predIndex_;
    std::vector<std::string> allKeys_;

    static std::string makeKey(const std::string& p, const std::string& s, const std::string& o);
    Fact keyToFact(const std::string& key) const;
};

} // namespace fic