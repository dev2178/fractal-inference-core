#ifndef FIC_C_API_H
#define FIC_C_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define FIC_MAX_PREMISES 4

typedef struct {
    char predicate[64];
    char subject[64];
    char object[64];
} FicTriple;

typedef struct {
    int numPremises;
    FicTriple premises[FIC_MAX_PREMISES];
    FicTriple conclusion;
    double strength;
} FicRule;

typedef struct {
    char predicate[64];
    char subject[64];
    char object[64];
    double confidence;
} FicFact;

typedef void FicEngine;

FicEngine* fic_create_engine(const FicRule* rules, int numRules,
                             const FicFact* facts, int numFacts,
                             int numAgents, int iterationsPerAgent);
FicFact* fic_run_inference(FicEngine* engine, int* resultCount);
void fic_free_results(FicFact* results);
void fic_add_fact(FicEngine* engine, const FicFact* fact);
int fic_fact_count(FicEngine* engine);
void fic_destroy_engine(FicEngine* engine);

#ifdef __cplusplus
}
#endif
#endif