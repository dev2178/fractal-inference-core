# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-01-20

### Added
- Initial public release
- Multi-premise conjunctive rules with variable binding (`?x` syntax)
- Shared confidence-weighted blackboard with predicate indexing
- Parallel fractal inference engine with configurable agent count
- Thread-safe concurrent read/write access to blackboard
- Random exploration strategy for diverse reasoning paths
- Confidence propagation with damping factor and exploration noise
- C API for cross-language integration (`c_api.h`)
- Modern CMake build system with install targets
- Unit tests using Google Test framework
- Example applications: family tree inference, medical diagnosis
- Documentation: API reference and theory overview
- MIT License

### Security
- Input validation on all C API boundaries
- Bounds checking on string copies
- Exception safety in C API wrappers

### Performance
- Predicate-based indexing for O(1) fact lookup
- Shared mutex for concurrent reads
- Agent-local random number generators to avoid lock contention