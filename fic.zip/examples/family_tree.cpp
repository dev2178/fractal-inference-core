#include <iostream>
#include <fic/engine.h>

int main() {
    std::vector<fic::Rule> rules = {
        { {{"parent", "?x", "?y"}, {"parent", "?y", "?z"}},
          {"grandparent", "?x", "?z"}, 0.95 }
    };

    std::vector<fic::Fact> facts = {
        {"parent", "Alice", "Bob", 1.0},
        {"parent", "Bob", "Charlie", 1.0},
        {"parent", "Alice", "Diana", 1.0},
        {"parent", "Diana", "Eve", 1.0}
    };

    fic::FractalInferenceCore engine(rules, facts, 4, 100);
    auto conclusions = engine.infer(0.5);

    std::cout << "=== Grandparent Inference ===" << std::endl;
    for (auto& f : conclusions) {
        std::cout << f.predicate << "(" << f.subject << ", " << f.object
                  << ") conf=" << f.confidence << std::endl;
    }
    return 0;
}