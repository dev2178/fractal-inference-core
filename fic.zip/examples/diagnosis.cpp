#include <iostream>
#include <fic/engine.h>

int main() {
    std::vector<fic::Rule> rules = {
        { {{"has_symptom", "?p", "fever"}, {"has_symptom", "?p", "cough"}},
          {"might_have", "?p", "flu"}, 0.8 },
        { {{"has_symptom", "?p", "fever"}, {"has_symptom", "?p", "rash"}},
          {"might_have", "?p", "measles"}, 0.7 }
    };

    std::vector<fic::Fact> facts = {
        {"has_symptom", "John", "fever", 0.9},
        {"has_symptom", "John", "cough", 0.85},
        {"has_symptom", "Jane", "fever", 0.9},
        {"has_symptom", "Jane", "rash", 0.8}
    };

    fic::FractalInferenceCore engine(rules, facts, 4, 100);
    auto conclusions = engine.infer(0.5);

    std::cout << "=== Diagnosis Guesses ===" << std::endl;
    for (auto& f : conclusions) {
        std::cout << f.predicate << "(" << f.subject << ", " << f.object
                  << ") conf=" << f.confidence << std::endl;
    }
    return 0;
}