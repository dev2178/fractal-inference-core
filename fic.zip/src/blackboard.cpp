#include "fic/blackboard.h"
#include <algorithm>
#include <shared_mutex>

namespace fic {

std::string Blackboard::makeKey(const std::string& p, const std::string& s, const std::string& o) {
    return p + "|" + s + "|" + o;
}

Fact Blackboard::keyToFact(const std::string& key) const {
    auto first = key.find('|');
    auto second = key.find('|', first + 1);
    Fact f;
    f.predicate = key.substr(0, first);
    f.subject   = key.substr(first + 1, second - first - 1);
    f.object    = key.substr(second + 1);
    auto it = store_.find(key);
    if (it != store_.end()) f.confidence = it->second.confidence;
    return f;
}

void Blackboard::insert(const Fact& f) {
    std::unique_lock lock(mutex_);
    std::string key = makeKey(f.predicate, f.subject, f.object);
    auto it = store_.find(key);
    if (it == store_.end()) {
        store_[key] = f;
        allKeys_.push_back(key);
        predIndex_[f.predicate].push_back(key);
    } else if (f.confidence > it->second.confidence) {
        it->second.confidence = f.confidence;
    }
}

std::vector<Fact> Blackboard::getAllFacts() const {
    std::shared_lock lock(mutex_);
    std::vector<Fact> facts;
    facts.reserve(store_.size());
    for (const auto& pair : store_) facts.push_back(pair.second);
    return facts;
}

std::vector<Fact> Blackboard::getFactsByPredicate(const std::string& predicate) const {
    std::shared_lock lock(mutex_);
    std::vector<Fact> result;
    auto it = predIndex_.find(predicate);
    if (it != predIndex_.end()) {
        result.reserve(it->second.size());
        for (const auto& key : it->second) {
            auto fit = store_.find(key);
            if (fit != store_.end()) result.push_back(fit->second);
        }
    }
    return result;
}

bool Blackboard::exists(const TriplePattern& pattern, const BindingMap& bindings,
                        double minConf) const {
    std::shared_lock lock(mutex_);
    auto resolve = [&](const std::string& s) -> std::string {
        if (TriplePattern::isVariable(s)) {
            auto it = bindings.find(s);
            return (it != bindings.end()) ? it->second : "";
        }
        return s;
    };
    std::string p = resolve(pattern.predicate);
    std::string s = resolve(pattern.subject);
    std::string o = resolve(pattern.object);
    if (p.empty() || s.empty() || o.empty()) return false;
    auto it = store_.find(makeKey(p, s, o));
    return it != store_.end() && it->second.confidence >= minConf;
}

std::optional<Fact> Blackboard::getRandomMatching(const TriplePattern& pattern,
                                                  const BindingMap& bindings,
                                                  std::mt19937& rng,
                                                  double minConf) const {
    std::shared_lock lock(mutex_);
    auto resolve = [&](const std::string& s) -> std::string {
        if (TriplePattern::isVariable(s)) {
            auto it = bindings.find(s);
            return (it != bindings.end()) ? it->second : "";
        }
        return s;
    };
    std::string p = resolve(pattern.predicate);
    std::string s = resolve(pattern.subject);
    std::string o = resolve(pattern.object);

    if (!p.empty() && !s.empty() && !o.empty()) {
        auto it = store_.find(makeKey(p, s, o));
        if (it != store_.end() && it->second.confidence >= minConf) return it->second;
        return std::nullopt;
    }

    auto predIt = predIndex_.find(p.empty() ? "" : p);
    if (predIt == predIndex_.end()) return std::nullopt;

    std::vector<std::string> candidates;
    for (const auto& key : predIt->second) {
        auto fit = store_.find(key);
        if (fit == store_.end() || fit->second.confidence < minConf) continue;
        const Fact& fact = fit->second;
        if ((s.empty() || fact.subject == s) && (o.empty() || fact.object == o))
            candidates.push_back(key);
    }
    if (candidates.empty()) return std::nullopt;

    std::uniform_int_distribution<size_t> dist(0, candidates.size() - 1);
    auto chosenKey = candidates[dist(rng)];
    auto it = store_.find(chosenKey);
    return (it != store_.end()) ? std::optional{it->second} : std::nullopt;
}

std::optional<Fact> Blackboard::getRandomFact(std::mt19937& rng) const {
    std::shared_lock lock(mutex_);
    if (allKeys_.empty()) return std::nullopt;
    std::uniform_int_distribution<size_t> dist(0, allKeys_.size() - 1);
    auto it = store_.find(allKeys_[dist(rng)]);
    if (it != store_.end()) return it->second;
    return std::nullopt;
}

double Blackboard::getConfidence(const Fact& f) const {
    std::shared_lock lock(mutex_);
    auto it = store_.find(makeKey(f.predicate, f.subject, f.object));
    return (it != store_.end()) ? it->second.confidence : 0.0;
}

size_t Blackboard::size() const {
    std::shared_lock lock(mutex_);
    return store_.size();
}

} // namespace fic