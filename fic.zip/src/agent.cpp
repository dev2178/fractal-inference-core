#include "fic/agent.h"
#include <algorithm>
#include <numeric>

namespace fic {

InferenceAgent::InferenceAgent(int id,
                               const std::vector<Rule>& rules,
                               const RuleIndex& ruleIndex,
                               Blackboard& blackboard)
    : id_(id), rules_(rules), ruleIndex_(ruleIndex), board_(blackboard),
      rng_(std::random_device{}()) {}

void InferenceAgent::run(int iterations) {
    constexpr int maxAttempts = 200;
    for (int i = 0; i < iterations; ++i) {
        bool progress = false;
        for (int attempt = 0; attempt < maxAttempts; ++attempt) {
            if (tryInferOnce()) { progress = true; break; }
        }
        if (!progress) break;
    }
}

bool InferenceAgent::tryInferOnce() {
    if (rules_.empty()) return false;
    std::uniform_int_distribution<size_t> ruleDist(0, rules_.size() - 1);
    const Rule& rule = rules_[ruleDist(rng_)];

    BindingMap bindings;
    if (!matchRule(rule, bindings)) return false;

    Fact conclusion;
    auto resolve = [&](const std::string& s) -> std::string {
        if (TriplePattern::isVariable(s)) {
            auto it = bindings.find(s);
            return (it != bindings.end()) ? it->second : s;
        }
        return s;
    };
    conclusion.predicate = resolve(rule.conclusion.predicate);
    conclusion.subject   = resolve(rule.conclusion.subject);
    conclusion.object    = resolve(rule.conclusion.object);

    double minConf = 1.0;
    for (const auto& prem : rule.premises) {
        Fact resolved;
        resolved.predicate = resolve(prem.predicate);
        resolved.subject   = resolve(prem.subject);
        resolved.object    = resolve(prem.object);
        double c = board_.getConfidence(resolved);
        if (c < minConf) minConf = c;
    }
    conclusion.confidence = std::clamp(minConf * rule.strength + noiseDist_(rng_), 0.0, 1.0);
    board_.insert(conclusion);
    return true;
}

bool InferenceAgent::matchRule(const Rule& rule, BindingMap& bindings) {
    if (rule.premises.empty()) return false;
    bindings.clear();

    std::vector<size_t> perm(rule.premises.size());
    std::iota(perm.begin(), perm.end(), 0);
    std::shuffle(perm.begin(), perm.end(), rng_);

    for (size_t idx : perm) {
        const TriplePattern& pattern = rule.premises[idx];
        auto factOpt = board_.getRandomMatching(pattern, bindings, rng_);
        if (!factOpt) return false;

        const Fact& fact = *factOpt;
        if (TriplePattern::isVariable(pattern.predicate))
            bindings[pattern.predicate] = fact.predicate;
        if (TriplePattern::isVariable(pattern.subject))
            bindings[pattern.subject] = fact.subject;
        if (TriplePattern::isVariable(pattern.object))
            bindings[pattern.object] = fact.object;
    }
    return true;
}

} // namespace fic