#include "fic/engine.h"
#include "fic/agent.h"
#include <thread>
#include <algorithm>

namespace fic {

FractalInferenceCore::FractalInferenceCore(std::vector<Rule> rules,
                                           std::vector<Fact> initialFacts,
                                           int numAgents,
                                           int iterationsPerAgent)
    : rules_(std::move(rules)),
      initialFacts_(std::move(initialFacts)),
      numAgents_(std::max(1, numAgents)),
      iterPerAgent_(std::max(1, iterationsPerAgent)),
      blackboard_(std::make_unique<Blackboard>())
{
    for (const auto& f : initialFacts_) blackboard_->insert(f);
    buildRuleIndex();
}

void FractalInferenceCore::buildRuleIndex() {
    ruleIndex_.clear();
    for (size_t i = 0; i < rules_.size(); ++i) {
        bool indexed = false;
        for (const auto& prem : rules_[i].premises) {
            if (!TriplePattern::isVariable(prem.predicate)) {
                ruleIndex_[prem.predicate].push_back(i);
                indexed = true;
                break;
            }
        }
        if (!indexed) ruleIndex_["*"].push_back(i);
    }
}

std::vector<Fact> FractalInferenceCore::infer(double confidenceThreshold) {
    std::vector<std::thread> threads;
    threads.reserve(numAgents_);
    for (int i = 0; i < numAgents_; ++i) {
        threads.emplace_back([this, i]() {
            InferenceAgent agent(i, rules_, ruleIndex_, *blackboard_);
            agent.run(iterPerAgent_);
        });
    }
    for (auto& t : threads) t.join();

    auto all = blackboard_->getAllFacts();
    std::vector<Fact> conclusions;
    for (auto& f : all) {
        if (f.confidence >= confidenceThreshold)
            conclusions.push_back(std::move(f));
    }
    std::sort(conclusions.begin(), conclusions.end(),
              [](const Fact& a, const Fact& b) { return a.confidence > b.confidence; });
    return conclusions;
}

void FractalInferenceCore::addFact(const Fact& f) {
    blackboard_->insert(f);
}

size_t FractalInferenceCore::factCount() const {
    return blackboard_->size();
}

} // namespace fic