#include "fic/c_api.h"
#include "fic/engine.h"
#include <cstring>
#include <algorithm>

static void safeCopy(char* dst, const char* src, size_t n) {
    if (!dst || !src || n == 0) return;
    size_t i = 0;
    for (; i < n - 1 && src[i]; ++i) dst[i] = src[i];
    dst[i] = '\0';
}

extern "C" {

FicEngine* fic_create_engine(const FicRule* rules, int nr,
                             const FicFact* facts, int nf,
                             int na, int iter) {
    if (!rules || !facts || nr <= 0 || nf <= 0 || na <= 0 || iter <= 0) return nullptr;

    std::vector<fic::Rule> cppRules(nr);
    for (int i = 0; i < nr; ++i) {
        cppRules[i].premises.resize(rules[i].numPremises);
        for (int j = 0; j < rules[i].numPremises; ++j) {
            safeCopy(cppRules[i].premises[j].predicate, rules[i].premises[j].predicate, 64);
            safeCopy(cppRules[i].premises[j].subject,   rules[i].premises[j].subject,   64);
            safeCopy(cppRules[i].premises[j].object,    rules[i].premises[j].object,    64);
        }
        safeCopy(cppRules[i].conclusion.predicate, rules[i].conclusion.predicate, 64);
        safeCopy(cppRules[i].conclusion.subject,   rules[i].conclusion.subject,   64);
        safeCopy(cppRules[i].conclusion.object,    rules[i].conclusion.object,    64);
        cppRules[i].strength = std::clamp(rules[i].strength, 0.0, 1.0);
    }

    std::vector<fic::Fact> cppFacts(nf);
    for (int i = 0; i < nf; ++i) {
        safeCopy(cppFacts[i].predicate, facts[i].predicate, 64);
        safeCopy(cppFacts[i].subject,   facts[i].subject,   64);
        safeCopy(cppFacts[i].object,    facts[i].object,    64);
        cppFacts[i].confidence = std::clamp(facts[i].confidence, 0.0, 1.0);
    }

    try {
        return reinterpret_cast<FicEngine*>(
            new fic::FractalInferenceCore(std::move(cppRules), std::move(cppFacts), na, iter));
    } catch (...) { return nullptr; }
}

FicFact* fic_run_inference(FicEngine* e, int* count) {
    if (!e || !count) return nullptr;
    auto* core = reinterpret_cast<fic::FractalInferenceCore*>(e);
    std::vector<fic::Fact> conclusions;
    try { conclusions = core->infer(0.6); }
    catch (...) { *count = 0; return nullptr; }
    *count = static_cast<int>(conclusions.size());
    if (conclusions.empty()) return nullptr;
    auto* arr = new FicFact[conclusions.size()];
    for (size_t i = 0; i < conclusions.size(); ++i) {
        safeCopy(arr[i].predicate, conclusions[i].predicate.c_str(), 64);
        safeCopy(arr[i].subject,   conclusions[i].subject.c_str(),   64);
        safeCopy(arr[i].object,    conclusions[i].object.c_str(),    64);
        arr[i].confidence = conclusions[i].confidence;
    }
    return arr;
}

void fic_free_results(FicFact* p) { delete[] p; }

void fic_add_fact(FicEngine* e, const FicFact* f) {
    if (!e || !f) return;
    fic::Fact fact;
    safeCopy(fact.predicate, f->predicate, 64);
    safeCopy(fact.subject,   f->subject,   64);
    safeCopy(fact.object,    f->object,    64);
    fact.confidence = std::clamp(f->confidence, 0.0, 1.0);
    reinterpret_cast<fic::FractalInferenceCore*>(e)->addFact(fact);
}

int fic_fact_count(FicEngine* e) {
    if (!e) return 0;
    return static_cast<int>(reinterpret_cast<fic::FractalInferenceCore*>(e)->factCount());
}

void fic_destroy_engine(FicEngine* e) {
    delete reinterpret_cast<fic::FractalInferenceCore*>(e);
}

} // extern "C"