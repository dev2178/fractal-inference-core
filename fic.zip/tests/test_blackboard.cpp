#include <gtest/gtest.h>
#include <fic/blackboard.h>
#include <random>

TEST(Blackboard, InsertAndQuery) {
    fic::Blackboard bb;
    bb.insert({"likes", "dog", "bone", 0.8});
    EXPECT_TRUE(bb.exists({"likes", "dog", "bone"}, {}));
    EXPECT_DOUBLE_EQ(bb.getConfidence({"likes", "dog", "bone"}), 0.8);
}

TEST(Blackboard, HigherConfidenceWins) {
    fic::Blackboard bb;
    bb.insert({"ate", "cat", "fish", 0.6});
    bb.insert({"ate", "cat", "fish", 0.9});
    EXPECT_DOUBLE_EQ(bb.getConfidence({"ate", "cat", "fish"}), 0.9);
}

TEST(Blackboard, LowerConfidenceIgnored) {
    fic::Blackboard bb;
    bb.insert({"ate", "cat", "fish", 0.9});
    bb.insert({"ate", "cat", "fish", 0.3});
    EXPECT_DOUBLE_EQ(bb.getConfidence({"ate", "cat", "fish"}), 0.9);
}

TEST(Blackboard, GetNonExistentConfidence) {
    fic::Blackboard bb;
    EXPECT_DOUBLE_EQ(bb.getConfidence({"nope", "none", "nothing"}), 0.0);
}

TEST(Blackboard, GetAllFacts) {
    fic::Blackboard bb;
    bb.insert({"a", "b", "c", 0.5});
    bb.insert({"d", "e", "f", 0.7});
    auto facts = bb.getAllFacts();
    EXPECT_EQ(facts.size(), 2);
}

TEST(Blackboard, GetFactsByPredicate) {
    fic::Blackboard bb;
    bb.insert({"likes", "Alice", "cake", 0.9});
    bb.insert({"likes", "Bob", "pie", 0.8});
    bb.insert({"hates", "Alice", "broccoli", 1.0});
    EXPECT_EQ(bb.getFactsByPredicate("likes").size(), 2);
    EXPECT_EQ(bb.getFactsByPredicate("hates").size(), 1);
    EXPECT_TRUE(bb.getFactsByPredicate("xyz").empty());
}

TEST(Blackboard, ExistsWithBindings) {
    fic::Blackboard bb;
    bb.insert({"likes", "Alice", "cake", 0.9});
    fic::BindingMap bindings = {{"?x", "Alice"}};
    EXPECT_TRUE(bb.exists({"likes", "?x", "cake"}, bindings));
    EXPECT_FALSE(bb.exists({"likes", "?x", "pie"}, bindings));
}

TEST(Blackboard, ExistsWithMinConfidence) {
    fic::Blackboard bb;
    bb.insert({"likes", "Alice", "cake", 0.3});
    EXPECT_TRUE(bb.exists({"likes", "Alice", "cake"}, {}, 0.0));
    EXPECT_TRUE(bb.exists({"likes", "Alice", "cake"}, {}, 0.2));
    EXPECT_FALSE(bb.exists({"likes", "Alice", "cake"}, {}, 0.5));
}

TEST(Blackboard, RandomMatchingWithVariable) {
    fic::Blackboard bb;
    bb.insert({"color", "sky", "blue", 1.0});
    bb.insert({"color", "grass", "green", 1.0});
    std::mt19937 rng(42);
    auto f = bb.getRandomMatching({"color", "?x", "blue"}, {}, rng);
    ASSERT_TRUE(f.has_value());
    EXPECT_EQ(f->subject, "sky");
}

TEST(Blackboard, RandomMatchingNoMatch) {
    fic::Blackboard bb;
    bb.insert({"color", "sky", "blue", 1.0});
    std::mt19937 rng(42);
    auto f = bb.getRandomMatching({"color", "?x", "red"}, {}, rng);
    EXPECT_FALSE(f.has_value());
}

TEST(Blackboard, Size) {
    fic::Blackboard bb;
    EXPECT_EQ(bb.size(), 0);
    bb.insert({"a", "b", "c", 0.1});
    EXPECT_EQ(bb.size(), 1);
    bb.insert({"a", "b", "c", 0.9}); // update, not new
    EXPECT_EQ(bb.size(), 1);
}

TEST(Blackboard, ThreadSafetyInsert) {
    fic::Blackboard bb;
    const int numThreads = 10;
    const int itemsPerThread = 100;
    std::vector<std::thread> threads;
    for (int t = 0; t < numThreads; ++t) {
        threads.emplace_back([&bb, t]() {
            for (int i = 0; i < itemsPerThread; ++i) {
                bb.insert({"pred", "s" + std::to_string(t) + "_" + std::to_string(i), "o", 0.5});
            }
        });
    }
    for (auto& th : threads) th.join();
    EXPECT_EQ(bb.size(), numThreads * itemsPerThread);
}