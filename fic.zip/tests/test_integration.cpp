#include <gtest/gtest.h>
#include <fic/engine.h>

TEST(Integration, FamilyTree) {
    std::vector<fic::Rule> rules = {
        { {{"parent", "?x", "?y"}, {"parent", "?y", "?z"}},
          {"grandparent", "?x", "?z"}, 1.0 }
    };
    std::vector<fic::Fact> facts = {
        {"parent", "A", "B", 1.0},
        {"parent", "B", "C", 1.0},
        {"parent", "C", "D", 1.0}
    };
    fic::FractalInferenceCore engine(rules, facts, 4, 200);
    auto conclusions = engine.infer(0.5);

    bool hasAB = false, hasAC = false, hasBD = false;
    for (auto& f : conclusions) {
        if (f.predicate == "grandparent") {
            if (f.subject == "A" && f.object == "C") hasAC = true;
            if (f.subject == "A" && f.object == "B") hasAB = true; // invalid, should not exist
            if (f.subject == "B" && f.object == "D") hasBD = true;
        }
    }
    EXPECT_FALSE(hasAB); // A is parent of B, not grandparent
    EXPECT_TRUE(hasAC);
    EXPECT_TRUE(hasBD);
}

TEST(Integration, Diagnosis) {
    std::vector<fic::Rule> rules = {
        { {{"has_symptom", "?p", "fever"}, {"has_symptom", "?p", "cough"}},
          {"might_have", "?p", "flu"}, 0.8 },
        { {{"has_symptom", "?p", "fever"}, {"has_symptom", "?p", "rash"}},
          {"might_have", "?p", "measles"}, 0.7 }
    };
    std::vector<fic::Fact> facts = {
        {"has_symptom", "John", "fever", 0.9},
        {"has_symptom", "John", "cough", 0.85}
    };
    fic::FractalInferenceCore engine(rules, facts, 4, 100);
    auto conclusions = engine.infer(0.5);

    bool fluFound = false;
    for (auto& f : conclusions) {
        if (f.predicate == "might_have" && f.subject == "John" && f.object == "flu") {
            fluFound = true;
            EXPECT_GE(f.confidence, 0.68); // min(0.9,0.85)*0.8 ≈ 0.68
        }
    }
    EXPECT_TRUE(fluFound);
}

TEST(Integration, C_API) {
    FicRule rules[1];
    rules[0].numPremises = 2;
    strcpy(rules[0].premises[0].predicate, "parent");
    strcpy(rules[0].premises[0].subject, "?x");
    strcpy(rules[0].premises[0].object, "?y");
    strcpy(rules[0].premises[1].predicate, "parent");
    strcpy(rules[0].premises[1].subject, "?y");
    strcpy(rules[0].premises[1].object, "?z");
    strcpy(rules[0].conclusion.predicate, "grandparent");
    strcpy(rules[0].conclusion.subject, "?x");
    strcpy(rules[0].conclusion.object, "?z");
    rules[0].strength = 1.0;

    FicFact facts[2];
    strcpy(facts[0].predicate, "parent");
    strcpy(facts[0].subject, "X");
    strcpy(facts[0].object, "Y");
    facts[0].confidence = 1.0;
    strcpy(facts[1].predicate, "parent");
    strcpy(facts[1].subject, "Y");
    strcpy(facts[1].object, "Z");
    facts[1].confidence = 1.0;

    FicEngine* eng = fic_create_engine(rules, 1, facts, 2, 2, 100);
    ASSERT_NE(eng, nullptr);

    int count = 0;
    FicFact* results = fic_run_inference(eng, &count);
    EXPECT_GT(count, 0);
    bool found = false;
    for (int i = 0; i < count; ++i) {
        if (strcmp(results[i].predicate, "grandparent") == 0 &&
            strcmp(results[i].subject, "X") == 0 &&
            strcmp(results[i].object, "Z") == 0) {
            found = true;
            EXPECT_GE(results[i].confidence, 0.9);
        }
    }
    EXPECT_TRUE(found);
    fic_free_results(results);
    fic_destroy_engine(eng);
}