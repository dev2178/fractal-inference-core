#include <gtest/gtest.h>
#include <fic/agent.h>
#include <fic/blackboard.h>

TEST(Agent, TransitiveInference) {
    std::vector<fic::Rule> rules = {
        { {{"parent", "?x", "?y"}, {"parent", "?y", "?z"}},
          {"grandparent", "?x", "?z"}, 1.0 }
    };
    fic::RuleIndex index;
    index["parent"].push_back(0);
    fic::Blackboard bb;
    bb.insert({"parent", "A", "B", 1.0});
    bb.insert({"parent", "B", "C", 1.0});

    fic::InferenceAgent agent(0, rules, index, bb);
    agent.run(100);

    auto facts = bb.getAllFacts();
    bool found = false;
    for (auto& f : facts) {
        if (f.predicate == "grandparent" && f.subject == "A" && f.object == "C") {
            found = true;
            EXPECT_GE(f.confidence, 0.9);
        }
    }
    EXPECT_TRUE(found);
}

TEST(Agent, NoApplicableRule) {
    std::vector<fic::Rule> rules = {
        { {{"parent", "?x", "?y"}}, {"child", "?y", "?x"}, 1.0 }
    };
    fic::RuleIndex index;
    index["parent"].push_back(0);
    fic::Blackboard bb;
    bb.insert({"color", "sky", "blue", 1.0});

    fic::InferenceAgent agent(0, rules, index, bb);
    agent.run(50);
    // No parent fact, so no inference
    auto facts = bb.getAllFacts();
    EXPECT_EQ(facts.size(), 1);
}

TEST(Agent, MultipleAgentsConcurrent) {
    std::vector<fic::Rule> rules = {
        { {{"parent", "?x", "?y"}, {"parent", "?y", "?z"}},
          {"grandparent", "?x", "?z"}, 0.95 }
    };
    fic::RuleIndex index;
    index["parent"].push_back(0);
    fic::Blackboard bb;
    for (int i = 0; i < 10; ++i) {
        bb.insert({"parent", "p" + std::to_string(i), "p" + std::to_string(i+1), 1.0});
    }
    std::vector<std::thread> threads;
    for (int i = 0; i < 4; ++i) {
        threads.emplace_back([&, i]() {
            fic::InferenceAgent agent(i, rules, index, bb);
            agent.run(50);
        });
    }
    for (auto& t : threads) t.join();
    // Should have derived grandparent facts
    auto facts = bb.getFactsByPredicate("grandparent");
    EXPECT_GT(facts.size(), 0);
}